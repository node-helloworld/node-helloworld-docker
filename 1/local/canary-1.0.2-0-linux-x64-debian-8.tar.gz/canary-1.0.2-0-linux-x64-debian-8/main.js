'use strict';

const componentFunctions = require('./lib/component')($app);

$app.postInstallation = function() {
  const systemUser = $app.service.start.username;
  $os.addGroup(systemUser);
  $os.addUser(systemUser, {gid: systemUser});
  componentFunctions.configurePermissions([$app.installdir],
          {user: systemUser}, {followInnerSymLinks: true});
  componentFunctions.createExtraConfigurationFiles([
    {type: 'monit', path: $app.monitFile, params: {service: 'canary', pidFile: $app.pidFile}},
    {type: 'logrotate', path: $app.logrotateFile, params: {logPath: $file.join($app.installdir, '*log')}}
  ]);
  $file.write($file.join($app.installdir, 'name.txt'), $app.helloname);
};
